package net.hb.bbs;

public interface BoardService {
	
			
}
