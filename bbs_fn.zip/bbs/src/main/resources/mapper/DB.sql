
 desc login;
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------
 USERID                                    NOT NULL VARCHAR2(10)
 PWD                                       NOT NULL VARCHAR2(4)

 